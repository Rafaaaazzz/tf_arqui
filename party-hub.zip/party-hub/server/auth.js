const express = require('express');
const router = express.Router();

router.post('/register', async (req, res) => {
    const { name, dni, birthdate, email, password } = req.body;

    // Validar DNI
    if (!/^\d{8}$/.test(dni)) {
        return res.status(400).json({ message: 'El DNI debe tener 8 dígitos.' });
    }

    // Validar edad
    const birthDateObj = new Date(birthdate);
    const today = new Date();
    const age = today.getFullYear() - birthDateObj.getFullYear();
    const monthDifference = today.getMonth() - birthDateObj.getMonth();
    if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < birthDateObj.getDate())) {
        age--;
    }

    if (age < 18) {
        return res.status(400).json({ message: 'Debes ser mayor de edad (18 años o más) para registrarte.' });
    }

    // Registro exitoso (simulado)
    console.log(`Usuario registrado: ${name}, DNI: ${dni}, Edad: ${age}, Email: ${email}`);
    res.status(201).json({ message: 'Registro exitoso.' });
});

module.exports = router;
