document.getElementById('register-form')?.addEventListener('submit', function (e) {
    const dni = document.getElementById('dni').value;
    const birthdate = new Date(document.getElementById('birthdate').value);
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;

    // Validar que el DNI tenga 8 dígitos
    if (dni.length !== 8 || !/^\d{8}$/.test(dni)) {
        e.preventDefault();
        alert('El DNI debe tener exactamente 8 dígitos.');
        return;
    }

    // Validar edad (mayor o igual a 18 años)
    const today = new Date();
    const age = today.getFullYear() - birthdate.getFullYear();
    const monthDifference = today.getMonth() - birthdate.getMonth();
    if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < birthdate.getDate())) {
        age--; // Ajustar si no ha cumplido años este año
    }

    if (age < 18) {
        e.preventDefault();
        alert('Debes ser mayor de edad (18 años o más) para registrarte.');
        return;
    }

    // Validar que las contraseñas coincidan
    if (password !== confirmPassword) {
        e.preventDefault();
        alert('Las contraseñas no coinciden.');
        return;
    }
});
